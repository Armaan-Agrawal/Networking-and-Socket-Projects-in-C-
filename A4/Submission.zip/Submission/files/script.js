function popup() {
    alert("It works...");
}
